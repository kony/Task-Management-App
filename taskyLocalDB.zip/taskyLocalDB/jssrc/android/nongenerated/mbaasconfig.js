function getKonyMBAASAppKey() {
    return env.appKey;
}

function getKonyMBAASAppSecret() {
    return env.appSecret;
}

function getKonyMBAASServiceUrl() {
    return env.serviceURL;
}
var env = {
    "appKey": "826a49543eb12a4b8d2730de7df5d0f",
    "appSecret": "1d408a3b464f9e0615e97feea924fdc0",
    "serviceURL": "https://100000012.auth.qa-konycloud.com/appconfig"
};
var google = {
    "provider_name": "TaskGoogleOAuth"
};