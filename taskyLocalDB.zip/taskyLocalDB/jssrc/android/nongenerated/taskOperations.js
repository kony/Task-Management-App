var TaskListId = "MTUwNDMxNzY4NzQ0Mjk3MzY3NTg6NTY2NjMwNzkzOjA";
var TaskId = "";

function getAllTasks() {
    kony.application.showLoadingScreen("sknLoading", "fetching tasks....", constants.LOADING_SCREEN_POSITION_ONLY_CENTER, true, true, null);
    var integrationClient = null;
    var serviceName = "Tasks";
    var operationName = "getAllTasks";
    var params = {
        "TaskListId": TaskListId
    };
    var headers = {}; //If there are no headers,pass null
    try {
        integrationClient = client.getIntegrationService(serviceName);
    } catch (exception) {
        kony.print("Exception" + exception.message);
        kony.application.dismissLoadingScreen();
    }
    integrationClient.invokeOperation(operationName, headers, params, function(response) {
        kony.print("Integration Service Response is :" + JSON.stringify(response));
        // alert("Integration Service Response is :" + JSON.stringify(response));
        loadTaskList(response);
        kony.application.dismissLoadingScreen();
    }, function(error) {
        kony.print("Integration Service Failure :" + JSON.stringify(error));
        alert("Integration Service Failure :" + JSON.stringify(error));
        kony.application.dismissLoadingScreen();
    });
}

function getTask(id) {
    kony.application.showLoadingScreen("sknLoading", "fetching task Details....", constants.LOADING_SCREEN_POSITION_ONLY_CENTER, true, true, null);
    if (kony.os.deviceInfo().name == "iPhone") {
        taskDetail.saveButtonIOS.text = "Save";
        taskDetail.deleteButtonAndroid = "Delete";
    } else if (kony.os.deviceInfo().name == "android") {
        taskDetail.saveButtonAndroid.text = "SAVE";
        taskDetail.deleteButtonAndroid.text = "DELETE";
    }
    var integrationClient = null;
    var serviceName = "Tasks";
    var operationName = "getTask";
    var params = {
        "TaskListId": TaskListId,
        "TaskId": id
    };
    var headers = {}; //If there are no headers,pass null
    try {
        integrationClient = client.getIntegrationService(serviceName);
    } catch (exception) {
        kony.print("Exception" + exception.message);
        kony.application.dismissLoadingScreen();
    }
    integrationClient.invokeOperation(operationName, headers, params, function(response) {
        kony.print("Integration Service Response is :" + JSON.stringify(response));
        //alert("Integration Service Response is :" + JSON.stringify(response));
        loadTaskDetails(response);
        kony.application.dismissLoadingScreen();
    }, function(error) {
        kony.print("Integration Service Failure :" + JSON.stringify(error));
        alert("Integration Service Failure :" + JSON.stringify(error));
        kony.application.dismissLoadingScreen();
    });
}

function createTask() {
    var integrationClient = null;
    var serviceName = "Tasks";
    var operationName = "createTask";
    var title = taskDetail.txtbxTitle.text;
    var notes = taskDetail.txtbxNotes.text;
    if (title === null || title === "") {
        alert("Please enter Title");
        return;
    } else if (notes === null || notes === "") {
        alert("Please enter notes");
        return;
    }
    kony.application.showLoadingScreen("sknLoading", "Creating task....", constants.LOADING_SCREEN_POSITION_ONLY_CENTER, true, true, null);
    var params = {
        "TaskListId": TaskListId,
        "title": title,
        "notes": notes
    };
    var headers = {}; //If there are no headers,pass null
    try {
        integrationClient = client.getIntegrationService(serviceName);
    } catch (exception) {
        kony.print("Exception" + exception.message);
        kony.application.dismissLoadingScreen();
    }
    integrationClient.invokeOperation(operationName, headers, params, function(response) {
        kony.print("Integration Service Response is :" + JSON.stringify(response));
        // alert("Integration Service Response is :" + JSON.stringify(response));
        //loadTaskList(response);
        taskList.show();
        getAllTasks();
        kony.application.dismissLoadingScreen();
    }, function(error) {
        kony.print("Integration Service Failure :" + JSON.stringify(error));
        alert("Integration Service Failure :" + JSON.stringify(error));
        kony.application.dismissLoadingScreen();
    });
}

function updateTask() {
    kony.application.showLoadingScreen("sknLoading", "updating task....", constants.LOADING_SCREEN_POSITION_ONLY_CENTER, true, true, null);
    var integrationClient = null;
    var serviceName = "Tasks";
    var operationName = "updateTask";
    var title = taskDetail.txtbxTitle.text;
    var notes = taskDetail.txtbxNotes.text;
    var params = {
        "TaskListId": TaskListId,
        "TaskId": TaskId,
        "title": title,
        "notes": notes,
        "status": "completed",
        "due": ""
    };
    var headers = {}; //If there are no headers,pass null
    try {
        integrationClient = client.getIntegrationService(serviceName);
    } catch (exception) {
        kony.print("Exception" + exception.message);
        kony.application.dismissLoadingScreen();
    }
    integrationClient.invokeOperation(operationName, headers, params, function(response) {
        kony.print("Integration Service Response is :" + JSON.stringify(response));
        // alert("Integration Service Response is :" + JSON.stringify(response));
        //loadTaskList(response);
        kony.application.dismissLoadingScreen();
        getAllTasks();
    }, function(error) {
        kony.print("Integration Service Failure :" + JSON.stringify(error));
        alert("Integration Service Failure :" + JSON.stringify(error));
        kony.application.dismissLoadingScreen();
    });
}

function deleteTask() {
    kony.application.showLoadingScreen("sknLoading", "deleting task....", constants.LOADING_SCREEN_POSITION_ONLY_CENTER, true, true, null);
    var integrationClient = null;
    var serviceName = "Tasks";
    var operationName = "deleteTask";
    var title = taskDetail.txtbxTitle.text;
    var notes = taskDetail.txtbxNotes.text;
    var params = {
        "TaskListId": TaskListId,
        "TaskId": TaskId,
        "title": title,
        "notes": notes,
        "status": "completed",
        "due": ""
    };
    var headers = {}; //If there are no headers,pass null
    try {
        integrationClient = client.getIntegrationService(serviceName);
    } catch (exception) {
        kony.print("Exception" + exception.message);
        kony.application.dismissLoadingScreen();
    }
    integrationClient.invokeOperation(operationName, headers, params, function(response) {
        kony.print("Integration Service Response is :" + JSON.stringify(response));
        //  alert("Integration Service Response is :" + JSON.stringify(response));
        //loadTaskList(response);
        getAllTasks();
        taskList.show();
        kony.application.dismissLoadingScreen();
    }, function(error) {
        kony.print("Integration Service Failure :" + JSON.stringify(error));
        alert("Integration Service Failure :" + JSON.stringify(error));
        kony.application.dismissLoadingScreen();
    });
}

function loadTaskDetails(response) {
    taskDetail.txtbxTitle.text = response.title;
    taskDetail.txtbxNotes.text = response.notes;
    TaskId = response.id;
    //   if(response.status=="needsAction"){
    //   }
    taskDetail.show();
}