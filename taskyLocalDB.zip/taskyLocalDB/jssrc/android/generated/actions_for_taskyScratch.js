//actions.js file 
function AS_Button_2061212ad46840f18d5a0f96c8166dee(eventobject) {
    if (taskDetail.deleteButtonIOS.text === "Delete") {
        deleteTask();
    } else {
        taskList.show();
    }
}

function AS_Button_28da27bc27fc4cbca80e1706bede4de3(eventobject) {
    taskList.show();
}

function AS_Button_82cb1047a4794b91bb75b7b3eb621b7f(eventobject) {
    if (taskDetail.saveButtonAndroid.text === "SAVE") {
        updateTask();
    } else {
        createTask();
    }
}

function AS_Button_ae7685cc032a4ca08f7508131f9c40d0(eventobject) {
    taskDetail.txtbxTitle.text = "";
    taskDetail.txtbxNotes.text = "";
    if (kony.os.deviceInfo().name == "iPhone") {
        taskDetail.saveButtonIOS.text = "Add";
        taskDetail.deleteButtonAndroid = "Cancel";
    } else if (kony.os.deviceInfo().name == "android") {
        taskDetail.saveButtonAndroid.text = "Add";
        taskDetail.deleteButtonAndroid.text = "Cancel";
    }
    taskDetail.show();
}

function AS_Button_b8e7b0625fd941e0a0f922586da3ef58(eventobject) {
    if (taskDetail.saveButtonIOS.text === "Save") {
        updateTask();
    } else {
        createTask();
    }
}

function AS_Button_f29528808b88486a96c52ffb9b39fdff(eventobject) {
    if (taskDetail.deleteButtonAndroid.text === "DELETE") {
        deleteTask();
    } else {
        taskList.show();
    }
}

function AS_Form_43a4d1cc881a4ea2932ca3f4347131f2(eventobject) {
    return initializeClient.call(this);
}

function AS_Segment_3c2a89c09c2f4a68966054879eae10f7(eventobject, sectionNumber, rowNumber) {
    var segment = taskList.Segment098265c04911740.selectedRowIndex[0];
    var row = taskList.Segment098265c04911740.selectedRowIndex[1];
    id = taskList.Segment098265c04911740.selectedItems[0].lblID;
    getTask(id);
}