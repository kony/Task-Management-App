function addWidgetstaskDetail() {
    taskDetail.setDefaultUnit(kony.flex.DP);
    var FlexContainer0a084c6bbc7264c = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "55dp",
        "id": "FlexContainer0a084c6bbc7264c",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "slFbox",
        "top": "0dp",
        "width": "100%"
    }, {}, {});
    FlexContainer0a084c6bbc7264c.setDefaultUnit(kony.flex.DP);
    var FlexContainer06de2dd6718364f = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "bottom": 0,
        "clipBounds": true,
        "height": "1dp",
        "id": "FlexContainer06de2dd6718364f",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "CopyslFbox04dc7887d44774d",
        "width": "100%"
    }, {}, {});
    FlexContainer06de2dd6718364f.setDefaultUnit(kony.flex.DP);
    FlexContainer06de2dd6718364f.add();
    var Label006def214a2384c = new kony.ui.Label({
        "centerX": "50%",
        "centerY": "50%",
        "height": "100%",
        "id": "Label006def214a2384c",
        "isVisible": true,
        "left": "141dp",
        "skin": "CopyslLabel013ace7d85ceb40",
        "text": "Tasky Pro",
        "top": "0dp",
        "width": "40%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var Image07027ce43695647 = new kony.ui.Image2({
        "centerY": "50%",
        "height": "45.45%",
        "id": "Image07027ce43695647",
        "isVisible": false,
        "left": "20dp",
        "skin": "slImage",
        "src": "backios.png",
        "top": "0dp",
        "width": "30dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var CopyImage00c9ff158656044 = new kony.ui.Image2({
        "centerY": "50%",
        "height": "45.45%",
        "id": "CopyImage00c9ff158656044",
        "isVisible": false,
        "right": "20dp",
        "skin": "slImage",
        "src": "plusios.png",
        "top": "0dp",
        "width": "30dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var backButtoniOS = new kony.ui.Image2({
        "centerY": "50%",
        "height": "45.45%",
        "id": "backButtoniOS",
        "isVisible": true,
        "left": "20dp",
        "skin": "slImage",
        "src": "backios.png",
        "top": "0dp",
        "width": "30dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var backButtonHeader = new kony.ui.Button({
        "focusSkin": "CopyslButtonGlossBlue0a30fbdac321e4b",
        "height": "100%",
        "id": "backButtonHeader",
        "isVisible": true,
        "left": "0dp",
        "onClick": AS_Button_28da27bc27fc4cbca80e1706bede4de3,
        "skin": "CopyslButtonGlossBlue041513b8bdf6240",
        "text": "Button",
        "top": "0dp",
        "width": "20%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "showProgressIndicator": true
    });
    FlexContainer0a084c6bbc7264c.add(FlexContainer06de2dd6718364f, Label006def214a2384c, Image07027ce43695647, CopyImage00c9ff158656044, backButtoniOS, backButtonHeader);
    var FlexContainer047261c92eeb84f = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "bottom": 0,
        "clipBounds": true,
        "id": "FlexContainer047261c92eeb84f",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "0dp",
        "skin": "slFbox",
        "top": "55dp",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    FlexContainer047261c92eeb84f.setDefaultUnit(kony.flex.DP);
    var FlexContainer0456b2772419440 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "55dp",
        "id": "FlexContainer0456b2772419440",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "slFbox",
        "top": "0dp",
        "width": "100%"
    }, {}, {});
    FlexContainer0456b2772419440.setDefaultUnit(kony.flex.DP);
    var FlexContainer0e393da8810cd45 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "bottom": 0,
        "clipBounds": true,
        "height": "1dp",
        "id": "FlexContainer0e393da8810cd45",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "10dp",
        "right": "10dp",
        "skin": "CopyslFbox04a1d620bcf124d"
    }, {}, {});
    FlexContainer0e393da8810cd45.setDefaultUnit(kony.flex.DP);
    FlexContainer0e393da8810cd45.add();
    var CopyFlexContainer002a7bdc50f5a4d = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "55dp",
        "id": "CopyFlexContainer002a7bdc50f5a4d",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_HORIZONTAL,
        "left": "0dp",
        "skin": "slFbox",
        "top": "0dp",
        "width": "100%"
    }, {}, {});
    CopyFlexContainer002a7bdc50f5a4d.setDefaultUnit(kony.flex.DP);
    var Label09009a3ea2c224b = new kony.ui.Label({
        "centerY": "50%",
        "height": "100%",
        "id": "Label09009a3ea2c224b",
        "isVisible": true,
        "left": "10dp",
        "skin": "CopyslLabel061a874fdbe394a",
        "text": "Name:",
        "top": "6dp",
        "width": "18%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var txtbxTitle = new kony.ui.TextBox2({
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "focusSkin": "CopyslTextBox02e49cc81bf184b",
        "height": "100%",
        "id": "txtbxTitle",
        "isVisible": true,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "left": "0dp",
        "maxTextLength": null,
        "secureTextEntry": false,
        "skin": "CopyslTextBox02e49cc81bf184b",
        "text": "Pick Up Groceries",
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "top": "0dp",
        "width": "75%",
        "zIndex": 1
    }, {
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [3, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "autoCorrect": false,
        "keyboardActionLabel": constants.TEXTBOX_KEYBOARD_LABEL_DONE,
        "showClearButton": true,
        "showCloseButton": true,
        "showProgressIndicator": true,
        "viewType": constants.TEXTBOX_VIEW_TYPE_DEFAULT
    });
    CopyFlexContainer002a7bdc50f5a4d.add(Label09009a3ea2c224b, txtbxTitle);
    FlexContainer0456b2772419440.add(FlexContainer0e393da8810cd45, CopyFlexContainer002a7bdc50f5a4d);
    var CopyFlexContainer0eea582c0edb34d = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "55dp",
        "id": "CopyFlexContainer0eea582c0edb34d",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "slFbox",
        "top": "0dp",
        "width": "100%"
    }, {}, {});
    CopyFlexContainer0eea582c0edb34d.setDefaultUnit(kony.flex.DP);
    var CopyFlexContainer01c6721ad64ce48 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "bottom": 0,
        "clipBounds": true,
        "height": "1dp",
        "id": "CopyFlexContainer01c6721ad64ce48",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "10dp",
        "right": "10dp",
        "skin": "CopyslFbox04a1d620bcf124d"
    }, {}, {});
    CopyFlexContainer01c6721ad64ce48.setDefaultUnit(kony.flex.DP);
    CopyFlexContainer01c6721ad64ce48.add();
    var CopyFlexContainer02007713df2d047 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "55dp",
        "id": "CopyFlexContainer02007713df2d047",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_HORIZONTAL,
        "left": "0dp",
        "skin": "slFbox",
        "top": "0dp",
        "width": "100%"
    }, {}, {});
    CopyFlexContainer02007713df2d047.setDefaultUnit(kony.flex.DP);
    var CopyLabel02d9f74a9921044 = new kony.ui.Label({
        "centerY": "50%",
        "height": "100%",
        "id": "CopyLabel02d9f74a9921044",
        "isVisible": true,
        "left": "10dp",
        "skin": "CopyslLabel061a874fdbe394a",
        "text": "Notes:",
        "top": "6dp",
        "width": "18%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var txtbxNotes = new kony.ui.TextBox2({
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "focusSkin": "CopyslTextBox02e49cc81bf184b",
        "height": "100%",
        "id": "txtbxNotes",
        "isVisible": true,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "left": "0dp",
        "secureTextEntry": false,
        "skin": "CopyslTextBox02e49cc81bf184b",
        "text": "Don't forget milk",
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "top": "0dp",
        "width": "75%",
        "zIndex": 1
    }, {
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [3, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "autoCorrect": false,
        "keyboardActionLabel": constants.TEXTBOX_KEYBOARD_LABEL_DONE,
        "showClearButton": true,
        "showCloseButton": true,
        "showProgressIndicator": true,
        "viewType": constants.TEXTBOX_VIEW_TYPE_DEFAULT
    });
    CopyFlexContainer02007713df2d047.add(CopyLabel02d9f74a9921044, txtbxNotes);
    CopyFlexContainer0eea582c0edb34d.add(CopyFlexContainer01c6721ad64ce48, CopyFlexContainer02007713df2d047);
    var CopyFlexContainer0f0537b8b3f2546 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "55dp",
        "id": "CopyFlexContainer0f0537b8b3f2546",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "slFbox",
        "top": "0dp",
        "width": "100%"
    }, {}, {});
    CopyFlexContainer0f0537b8b3f2546.setDefaultUnit(kony.flex.DP);
    var CopyFlexContainer0f3ff1ac6908d45 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "bottom": 0,
        "clipBounds": true,
        "height": "1dp",
        "id": "CopyFlexContainer0f3ff1ac6908d45",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "10dp",
        "right": "10dp",
        "skin": "CopyslFbox04a1d620bcf124d"
    }, {}, {});
    CopyFlexContainer0f3ff1ac6908d45.setDefaultUnit(kony.flex.DP);
    CopyFlexContainer0f3ff1ac6908d45.add();
    var doneIos = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "55dp",
        "id": "doneIos",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_HORIZONTAL,
        "left": "0dp",
        "skin": "slFbox",
        "top": "0dp",
        "width": "100%"
    }, {}, {});
    doneIos.setDefaultUnit(kony.flex.DP);
    var CopyLabel08fba020104f844 = new kony.ui.Label({
        "centerY": "50%",
        "height": "100%",
        "id": "CopyLabel08fba020104f844",
        "isVisible": true,
        "left": "10dp",
        "skin": "CopyslLabel061a874fdbe394a",
        "text": "Done:",
        "top": "6dp",
        "width": "25%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var switchStatus = new kony.ui.Switch({
        "centerY": "70%",
        "height": "100%",
        "id": "switchStatus",
        "isVisible": true,
        "left": "0%",
        "leftSideText": "ON",
        "rightSideText": "OFF",
        "selectedIndex": 0,
        "skin": "slSwitch",
        "top": "23dp",
        "width": "100dp",
        "zIndex": 1
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    doneIos.add(CopyLabel08fba020104f844, switchStatus);
    CopyFlexContainer0f0537b8b3f2546.add(CopyFlexContainer0f3ff1ac6908d45, doneIos);
    var actionsIos = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "50dp",
        "id": "actionsIos",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "right": "10dp",
        "skin": "slFbox",
        "top": "10dp",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    actionsIos.setDefaultUnit(kony.flex.DP);
    var deleteButtonIOS = new kony.ui.Button({
        "focusSkin": "CopyslButtonGlossBlue040f803aa3cc34e",
        "height": "50dp",
        "id": "deleteButtonIOS",
        "isVisible": true,
        "left": "10dp",
        "onClick": AS_Button_2061212ad46840f18d5a0f96c8166dee,
        "right": "49%",
        "skin": "CopyslButtonGlossBlue02e0229a1b1e541",
        "text": "Delete",
        "top": "0dp",
        "width": "46%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "showProgressIndicator": true
    });
    var saveButtonIOS = new kony.ui.Button({
        "focusSkin": "CopyslButtonGlossBlue0fc267d42af8648",
        "height": "50dp",
        "id": "saveButtonIOS",
        "isVisible": true,
        "onClick": AS_Button_b8e7b0625fd941e0a0f922586da3ef58,
        "right": "10dp",
        "skin": "CopyslButtonGlossBlue0af3c9e688b2844",
        "text": "Save",
        "top": "0dp",
        "width": "46%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "showProgressIndicator": true
    });
    actionsIos.add(deleteButtonIOS, saveButtonIOS);
    FlexContainer047261c92eeb84f.add(FlexContainer0456b2772419440, CopyFlexContainer0eea582c0edb34d, CopyFlexContainer0f0537b8b3f2546, actionsIos);
    taskDetail.add(FlexContainer0a084c6bbc7264c, FlexContainer047261c92eeb84f);
};

function taskDetailGlobals() {
    taskDetail = new kony.ui.Form2({
        "addWidgets": addWidgetstaskDetail,
        "enabledForIdleTimeout": false,
        "id": "taskDetail",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "skin": "CopyslForm00eb6505b965542"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "configureExtendBottom": false,
        "configureExtendTop": false,
        "configureStatusBarStyle": false,
        "footerOverlap": false,
        "formTransparencyDuringPostShow": "100",
        "headerOverlap": false,
        "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_CANCEL,
        "needsIndicatorDuringPostShow": false,
        "retainScrollPosition": false,
        "titleBar": false,
        "titleBarSkin": "slTitleBar"
    });
    taskDetail.info = {
        "kuid": "65f1f162f0574139be7a908506ce58c8"
    };
};