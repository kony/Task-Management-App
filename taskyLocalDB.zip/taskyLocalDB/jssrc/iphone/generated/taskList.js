function addWidgetstaskList() {
    taskList.setDefaultUnit(kony.flex.DP);
    var FlexContainer0a084c6bbc7264c = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "55dp",
        "id": "FlexContainer0a084c6bbc7264c",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "slFbox",
        "top": "0dp",
        "width": "100%"
    }, {}, {});
    FlexContainer0a084c6bbc7264c.setDefaultUnit(kony.flex.DP);
    var FlexContainer06de2dd6718364f = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "bottom": 0,
        "clipBounds": true,
        "height": "1dp",
        "id": "FlexContainer06de2dd6718364f",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "CopyslFbox04dc7887d44774d",
        "width": "100%"
    }, {}, {});
    FlexContainer06de2dd6718364f.setDefaultUnit(kony.flex.DP);
    FlexContainer06de2dd6718364f.add();
    var Label006def214a2384c = new kony.ui.Label({
        "centerX": "50%",
        "centerY": "50%",
        "height": "100%",
        "id": "Label006def214a2384c",
        "isVisible": true,
        "left": "141dp",
        "skin": "CopyslLabel013ace7d85ceb40",
        "text": "Tasky Pro",
        "top": "0dp",
        "width": "40%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var addTaskIos = new kony.ui.Image2({
        "centerY": "50%",
        "height": "45.45%",
        "id": "addTaskIos",
        "isVisible": true,
        "right": "20dp",
        "skin": "slImage",
        "src": "plusios.png",
        "top": "0dp",
        "width": "30dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var addTaskButton = new kony.ui.Button({
        "focusSkin": "CopyslButtonGlossBlue0a30fbdac321e4b",
        "height": "100%",
        "id": "addTaskButton",
        "isVisible": true,
        "onClick": AS_Button_d80a2fd5fa044585b96f075af5257c66,
        "right": 0,
        "skin": "CopyslButtonGlossBlue041513b8bdf6240",
        "text": "Button",
        "top": "0dp",
        "width": "20%",
        "zIndex": 5
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "showProgressIndicator": true
    });
    FlexContainer0a084c6bbc7264c.add(FlexContainer06de2dd6718364f, Label006def214a2384c, addTaskIos, addTaskButton);
    var Segment098265c04911740 = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "bottom": "0dp",
        "data": [{
            "lblID": "",
            "lblTitle": ""
        }],
        "groupCells": false,
        "id": "Segment098265c04911740",
        "isVisible": true,
        "left": "0dp",
        "needPageIndicator": true,
        "onRowClick": AS_Segment_3c2a89c09c2f4a68966054879eae10f7,
        "pageOffDotImage": "pageoffdot.png",
        "pageOnDotImage": "pageondot.png",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "seg2Normal",
        "rowTemplate": FBox015dcfde6d44944,
        "scrollingEvents": {},
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorRequired": true,
        "showScrollbars": false,
        "top": "55dp",
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "lblID": "lblID",
            "lblTitle": "lblTitle"
        },
        "width": "100%",
        "zIndex": 1
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "bounces": true,
        "editStyle": constants.SEGUI_EDITING_STYLE_NONE,
        "enableDictionary": false,
        "indicator": constants.SEGUI_ROW_SELECT,
        "progressIndicatorColor": constants.PROGRESS_INDICATOR_COLOR_WHITE,
        "showProgressIndicator": true
    });
    taskList.add(FlexContainer0a084c6bbc7264c, Segment098265c04911740);
};

function taskListGlobals() {
    taskList = new kony.ui.Form2({
        "addWidgets": addWidgetstaskList,
        "bounces": false,
        "enableScrolling": false,
        "enabledForIdleTimeout": false,
        "id": "taskList",
        "init": AS_Form_43a4d1cc881a4ea2932ca3f4347131f2,
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "preShow": AS_Form_5fa3042e3756463a98f91f3da2c869fc,
        "skin": "CopyslForm0c938d98e2c0249"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "bounces": false,
        "configureExtendBottom": false,
        "configureExtendTop": false,
        "configureStatusBarStyle": false,
        "footerOverlap": false,
        "formTransparencyDuringPostShow": "100",
        "headerOverlap": false,
        "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_CANCEL,
        "needsIndicatorDuringPostShow": false,
        "retainScrollPosition": false,
        "titleBar": false,
        "titleBarSkin": "slTitleBar"
    });
    taskList.info = {
        "kuid": "4bf6300e9c2d4825b39558889bb1d820"
    };
};