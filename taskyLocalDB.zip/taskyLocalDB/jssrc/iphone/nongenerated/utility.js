function AddnewTask() {
    taskDetail.txtbxTitle.text = "";
    taskDetail.txtbxNotes.text = "";
    if (kony.os.deviceInfo().name == "iPhone") {
        taskDetail.saveButtonIOS.text = "Add";
        taskDetail.deleteButtonAndroid = "Cancel";
    } else if (kony.os.deviceInfo().name == "android") {
        taskDetail.saveButtonAndroid.text = "Add";
        taskDetail.deleteButtonAndroid.text = "Cancel";
    }
    taskDetail.show();
}

function getTaskDetailsSelected() {
    if (kony.os.deviceInfo().name == "iPhone") {
        taskDetail.saveButtonIOS.text = "Save";
        taskDetail.deleteButtonAndroid = "Delete";
    } else if (kony.os.deviceInfo().name == "android") {
        taskDetail.saveButtonAndroid.text = "SAVE";
        taskDetail.deleteButtonAndroid.text = "DELETE";
    }
    taskDetail.txtbxTitle.text = taskList.Segment098265c04911740.selectedItems[0].lblTitle; //
    taskDetail.txtbxNotes.text = taskList.Segment098265c04911740.selectedItems[0].lblID;
    taskDetail.show();
}