initialCheck = true;
/*****************************************************************
 *	Name    : success_sqlSelect
 *	Author  : Kony Solutions
 *	Purpose : To show all the rows of 'all_tasks' table in the form
 ******************************************************************/
function success_sqlSelect(transactionId, resultset) {
    tmpTaskListTitle = [];
    for (i = 0; i < resultset.rows.length; i++) {
        var rowItem = kony.db.sqlResultsetRowItem(transactionId, resultset, i);
        kony.print(" taskname:" + rowItem.taskName);
        tmpTaskListTitle.push({
            "lblTitle": rowItem.taskName,
            "lblID": rowItem.taskDetails
        });
    }
    taskList.Segment098265c04911740.setData(tmpTaskListTitle);
    // taskList.show();
}

function success_sqlSelectInsert(transactionId, resultset) {
    tmpTaskListTitle = [];
    for (i = 0; i < resultset.rows.length; i++) {
        var rowItem = kony.db.sqlResultsetRowItem(transactionId, resultset, i);
        kony.print(" taskname:" + rowItem.taskName);
        tmpTaskListTitle.push({
            "lblTitle": rowItem.taskName,
            "lblID": rowItem.taskDetails
        });
    }
    taskList.Segment098265c04911740.setData(tmpTaskListTitle);
    taskList.show();
}
/*****************************************************************
 *	Name    : success_dropTable
 *	Author  : Kony Solutions
 *	Purpose : To display a message on the console when table creation is unsuccessful.
 ******************************************************************/
function success_dropTable(transactionId, resultset) {
    kony.print("Table was dropped");
}
/*****************************************************************
 *	Name    : success_createTable
 *	Author  : Kony Solutions
 *	Purpose : To display a message when table creation is successful.
 ******************************************************************/
function success_createTable(transactionId, resultset) {
    kony.print("Table is created successfully");
    // transaction();
}

function success_insertTable(transactionId, resultset) {
    alert("Insert is done successfully");
}
/*****************************************************************
 *	Name    : commonErrorCallback
 *	Author  : Kony Solutions
 *	Purpose : To display error message on the console 
 ******************************************************************/
function commonErrorCallback(transactionId, error) {
    kony.print(" Error code:: " + error);
    kony.print(" Error message:: " + error.message);
}
/*****************************************************************
 *	Name    : commonVoidcallback
 *	Author  : Kony Solutions
 *	Purpose : To display success message on the console.
 ******************************************************************/
function commonVoidcallback() {
    kony.print("The transaction was executed successfully.");
}
/*****************************************************************kony.db.openDatabase
 *	Name    : createTable
 *	Author  : Kony Solutions
 *	Purpose : To create all_tasks table with 4 rows
 ******************************************************************/
function createTable(dbId) {
    //    var sqlStatement = "DROP TABLE IF EXISTS all_tasks";
    //     kony.db.executeSql(dbId,
    //         sqlStatement,
    //         null,
    //         success_dropTable,
    //         commonErrorCallback);
    //dbId
    var sqlStatement = "CREATE TABLE IF NOT EXISTS all_tasks(taskName TEXT,taskDetails TEXT)"; //taskid REAL PRIMARY KEY,
    kony.db.executeSql(dbId, sqlStatement, null, success_createTable, commonErrorCallback);
}
/*****************************************************************
 *	Name    : transaction
 *	Author  : Kony Solutions
 *	Purpose : To open a transaction on click of Add button.
 ******************************************************************/
function transaction() {
    baseObjectId = kony.db.openDatabase("webSqlDB", "1.0", "Sample SQL Database", 5 * 1024 * 1024);
    kony.db.transaction(baseObjectId, insertTable, commonErrorCallback, commonVoidcallback);
}
/*****************************************************************
 *	Name    : insertTable
 *	Author  : Kony Solutions
 *	Purpose : To insert row in the table
 ******************************************************************/
function insertTable(dbId) {
    var taskName = taskDetail.txtbxTitle.text;
    var taskDetails = taskDetail.txtbxNotes.text;
    var sqlStatement = "INSERT INTO all_tasks VALUES (\"" + taskName + "\",\"" + taskDetails + "\")"; //" + (count) + ",
    kony.db.executeSql(dbId, sqlStatement, null, success_sqlSelectInsert, commonErrorCallback);
    //     var sqlStatement = "SELECT * FROM all_tasks";
    //     kony.db.executeSql(dbId,
    //         sqlStatement,
    //         null,
    //         success_sqlSelect,
    //         commonErrorCallback);
}
/*****************************************************************
 *	Name    : createDB
 *	Author  : Kony Solutions
 *	Purpose : To create the database with employee_details table
 ******************************************************************/
function createDB() {
    webSQLFlag = 1;
    baseObjectId = kony.db.openDatabase("webSqlDB", "1.0", "Sample SQL Database", 5 * 1024 * 1024); // 5MB database
    kony.db.transaction(baseObjectId, createTable, commonErrorCallback, commonVoidcallback);
}
/*****************************************************************
 *	Name    : doTransactionsqlSelect
 *	Author  : Kony 
 *	Purpose : To initiate transaction to implement SQL statement 'SELECT' to select all the rows and to display the same.
 ******************************************************************/
function doTransactionsqlSelect() {
    try {
        if (webSQLFlag === 0) {
            alert("Please create the database and then try show data");
            return;
        }
        kony.db.transaction(baseObjectId, sqlSelect, commonErrorCallback, commonVoidcallback);
    } catch (err) {
        kony.print("error in  select transaction" + err);
        alert("Please create the database and then try show data");
    }
}
/*****************************************************************
 *	Name    : sqlSelect
 *	Author  : Kony 
 *	Purpose : To implement SQL statement 'SELECT' to select all the rows and to display the same.
 ******************************************************************/
function sqlSelect(dbId) {
    try {
        var sqlStatement = "SELECT * FROM all_tasks";
        kony.db.executeSql(dbId, sqlStatement, null, success_sqlSelect, commonErrorCallback);
    } catch (err) {
        kony.print("error while selecting " + err);
    }
}

function doTransactionDelete() {
    //Create a new read n write transaction
    try {
        if (webSQLFlag === 0) {
            alert("Please create the database and then try deleting data");
            return;
        }
        kony.db.transaction(baseObjectId, sqlDelete, commonErrorCallback, commonVoidcallback);
    } catch (e) {
        // todo: handle exception
        kony.print("************ error: " + e + "***********");
        alert("Please create the database and then try deleting data");
    }
}
/*****************************************************************
 *	Name    : sqlDelete
 *	Author  : Kony 
 *	Purpose : To delete the row which is having maximum id from the 'employee_details' table.
 ******************************************************************/
function sqlDelete(dbId) {
    var deleteTaskName = taskDetail.txtbxTitle.text;
    var sqlStatement = "DELETE FROM all_tasks WHERE taskName=(select \"" + deleteTaskName + "\" from all_tasks)";
    //Execute sql statement
    kony.db.executeSql(dbId, sqlStatement, null, success_sqlDelete, commonErrorCallback);
}
/*****************************************************************
 *	Name    : success_sqlDelete
 *	Author  : Kony 
 *	Purpose : To take care of numresults which is used in doTransactionsqlDelete function
 ******************************************************************/
function success_sqlDelete(transactionId, resultset) {
    tmpTaskListTitle = [];
    for (i = 0; i < resultset.rows.length; i++) {
        var rowItem = kony.db.sqlResultsetRowItem(transactionId, resultset, i);
        kony.print(" taskname:" + rowItem.taskName);
        tmpTaskListTitle.push({
            "lblTitle": rowItem.taskName,
            "lblID": rowItem.taskDetails
        });
    }
    taskList.Segment098265c04911740.setData(tmpTaskListTitle);
    taskList.show();
}
/*****************************************************************
 *	Name    : doTransactionUpdate
 *	Author  : Kony 
 *	Purpose : To initiate transaction to implement webSQL 'UPDATE' to update 'employee_details' table  
 ******************************************************************/
function doTransactionUpdate() {
    //Create a new read n write transaction
    try {
        if (webSQLFlag === 0) {
            alert("Please create the database and then try update data");
            return;
        }
        kony.db.transaction(baseObjectId, sqlUpdate, commonErrorCallback, commonVoidcallback);
    } catch (e) {
        // todo: handle exception
        kony.print("************ error: " + e + "***********");
        alert("Please create the database and then try update data");
    }
}
/*****************************************************************
 *	Name    : sqlUpdate
 *	Author  : Kony 
 *	Purpose : To implement webSQL 'UPDATE' to update 'employee_details' table  in such a way that employee John's depart number will be 30
 ******************************************************************/
function sqlUpdate(dbId) {
    var UpdateTaskDetails = taskDetail.txtbxNotes.text;
    var updateTaskName = taskDetail.txtbxTitle.text;
    var sqlStatement = "UPDATE all_tasks SET taskDetails=\"" + UpdateTaskDetails + "\" WHERE taskName=\"" + updateTaskName + "\" ";
    kony.db.executeSql(dbId, sqlStatement, null, success_sqlUpdate, commonErrorCallback);
}
/*****************************************************************
 *	Name    : success_sqlUpdate
 *	Author  : Kony 
 *	Purpose : To display a message when updating the data to 'employee_details' table is successful
 ******************************************************************/
function success_sqlUpdate(transactionId, resultset) {
    tmpTaskListTitle = [];
    for (i = 0; i < resultset.rows.length; i++) {
        var rowItem = kony.db.sqlResultsetRowItem(transactionId, resultset, i);
        kony.print(" taskname:" + rowItem.taskName);
        tmpTaskListTitle.push({
            "lblTitle": rowItem.taskName,
            "lblID": rowItem.taskDetails
        });
    }
    taskList.Segment098265c04911740.setData(tmpTaskListTitle);
    taskList.show();
}