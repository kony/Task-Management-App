function taskAddAction() {
    return AS_NamedActions_538e2854693c4aaaa5d4e5329679dbe7();
}

function AS_NamedActions_538e2854693c4aaaa5d4e5329679dbe7() {
    taskDetail.show();
}