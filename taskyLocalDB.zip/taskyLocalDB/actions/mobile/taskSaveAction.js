function taskSaveAction(eventobject) {
    return AS_Button_6566b1132a8641649da2ab9bc0533ff5(eventobject);
}

function AS_Button_6566b1132a8641649da2ab9bc0533ff5(eventobject) {
    taskList.show();
}