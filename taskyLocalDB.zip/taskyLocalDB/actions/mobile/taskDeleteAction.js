function taskDeleteAction(eventobject) {
    return AS_Button_d0348136eae54eec916b689016febc55(eventobject);
}

function AS_Button_d0348136eae54eec916b689016febc55(eventobject) {
    taskList.show();
}