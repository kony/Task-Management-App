function taskDetailAction(eventobject, sectionNumber, rowNumber) {
    return AS_Segment_a7165692c45d4a23ab05802355f16e06(eventobject, sectionNumber, rowNumber);
}

function AS_Segment_a7165692c45d4a23ab05802355f16e06(eventobject, sectionNumber, rowNumber) {
    taskDetail.show();
}