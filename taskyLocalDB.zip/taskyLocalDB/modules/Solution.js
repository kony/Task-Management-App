
// function init(){
  
//   //Sample code to initialize Kony MobileFabric Client
//       var appkey = "933a3d76a2628ec41e71f434db181d42";
//       var appsecret = "45c3b2751ab37c3b47779e24b06bf7ca";
//       var serviceURL = "https://100000012.auth.qa-konycloud.com/appconfig";

//       var client = new kony.sdk();
//       client.init(appkey, appsecret, serviceURL, function(response) {
//           kony.print("Init success");
//           alert("init sucess");
//       }, function(error) {
//           kony.print("Init Failure");
//           alert("Init Failure");
//       });
  
// }


// function authLogin(){
  
//       // Sample code to authenticate to Kony MobileFabric Client
//       var authClient = null;
//       var  providerName = "TaskGoogleOAuth";
//       try {
//           authClient = client.getIdentityService(providerName);
//       } catch (exception) {
//           kony.print("Exception" + exception.message);
//       }
//       authClient.login({}, 
//       function(response) {
//               kony.print("Login success" + JSON.stringify(response));
//         	  alert("Login success" + JSON.stringify(response));
//           }, function(error) {
//               kony.print("Login failure" + JSON.stringify(error));
//           }
//       );
  
// }

// var providerSelected="";

// function profile(provider_name,callback){
// 	var user_store_client = client.getIdentityService(provider_name);
//     user_store_client.getProfile(false, function(profile) {
//          callback(profile);
//       }, function(error) {
//       kony.application.dismissLoadingScreen();
//         alert("Error occured while fetching the profile.");
//     });
// } 



// function login(provider_name,display_profile,callback)
// {
  
//   if(res.code==1)
//     {
// 		try { 
// 			auth_client = client.getIdentityService(provider_name);
// 		} catch (exception) {
// 			alert("Exception" + exception.message);
// 		}
// 		auth_client.login({},
// 			function(response) {
//   kony.application.showLoadingScreen("sknLoading","Please Wait..",constants.LOADING_SCREEN_POSITION_ONLY_CENTER, true, true,null);
//           		  callback(provider_name,display_profile);
// 			}, function(error) {
// 				  alert("login failure"+error.message);
//         	}
// 		);
//     }
//   else
//     {
//       alert("issues with init");
//     }
// }


