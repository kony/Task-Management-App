var backendToken="";
var tmpTaskListTitle=[];
function googleLogin()
{
  
  authLogin();
}

function authLogin(){
  
      // Sample code to authenticate to Kony MobileFabric Client
      var authClient = null;
      var  providerName = "TaskGoogleOAuth";
      try {
          authClient = client.getIdentityService(providerName);
      } catch (exception) {
          kony.print("Exception" + exception.message);
         alert("Exception" + exception.message);
      }
      authClient.login({}, 
      function(response) {
              kony.print("Login success" + JSON.stringify(response));
        	 // alert("Login success" + JSON.stringify(response));
               getAllTasks();
              
              
          }, function(error) {
              kony.print("Login failure" + JSON.stringify(error));
        	   alert("Login failure" + JSON.stringify(response));
          }
      );
  
}

function getTasklist(){
var integrationClient = null;
var serviceName = "TaskLists";
var operationName = "getTaskLists";
var params = {};
var headers = {};//If there are no headers,pass null
try{
	integrationClient = client.getIntegrationService("TaskLists");
}
catch(exception){
	kony.print("Exception" + exception.message);
}
integrationClient.invokeOperation(operationName, headers,params , 
	function(response) {
	kony.print("Integration Service Response is :" + JSON.stringify(response));
     alert("Integration Service Response is :" + JSON.stringify(response));
    loadTaskList(response);
	}, 
	function(error) {
	kony.print("Integration Service Failure :" + JSON.stringify(error));
    alert("Integration Service Failure :" + JSON.stringify(error));
	}
);

}

function loadTaskList(response){
   var TaskList=response.Task;
       tmpTaskListTitle=[];
   for(i=0;i<TaskList.length;i++){
      tmpTaskListTitle.push({"lblTitle":TaskList[i].title,"lblID":TaskList[i].id});
      
      
     // alert(tmpTaskListTitle);
   }
   //alert(tmpTaskListTitle);
   taskList.Segment098265c04911740.setData(tmpTaskListTitle);
 // taskList.Segment098265c04911740.setDataAt(tmpTaskListTitle);
}