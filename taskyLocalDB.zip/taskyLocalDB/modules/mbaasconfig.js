function getKonyMBAASAppKey()
{
  
	return env.appKey;
}

function getKonyMBAASAppSecret()
{
	return env.appSecret;
}

function getKonyMBAASServiceUrl()
{
 	return env.serviceURL; 
}
var env={
"appKey":"f9ca75d74cd146fb795a1a55e70c833a",
"appSecret":"2b474802f924e363df953bf8d5507c24",
"serviceURL":"https://100000032.auth.konycloud.com/appconfig"
  
};

var google={"provider_name":"TaskGoogleOAuth"};

