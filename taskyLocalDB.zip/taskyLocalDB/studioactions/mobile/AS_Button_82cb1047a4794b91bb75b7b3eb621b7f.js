function AS_Button_82cb1047a4794b91bb75b7b3eb621b7f(eventobject) {
    if (taskDetail.saveButtonAndroid.text === "SAVE") {
        updateTask();
    } else {
        createTask();
    }
}