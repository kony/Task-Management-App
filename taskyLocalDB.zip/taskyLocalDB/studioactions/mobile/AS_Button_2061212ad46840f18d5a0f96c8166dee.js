function AS_Button_2061212ad46840f18d5a0f96c8166dee(eventobject) {
    if (taskDetail.deleteButtonIOS.text === "Delete") {
        doTransactionDelete();
    } else {
        taskList.show();
    }
}