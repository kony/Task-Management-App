function AS_Segment_3c2a89c09c2f4a68966054879eae10f7(eventobject, sectionNumber, rowNumber) {
    var segment = taskList.Segment098265c04911740.selectedRowIndex[0];
    var row = taskList.Segment098265c04911740.selectedRowIndex[1];
    getTaskDetailsSelected();
    //getTask(id);
}