function AS_Button_b8e7b0625fd941e0a0f922586da3ef58(eventobject) {
    if (taskDetail.saveButtonIOS.text === "Save") {
        doTransactionUpdate();
    } else {
        //createTask();
        // insertTable();
        transaction();
    }
}