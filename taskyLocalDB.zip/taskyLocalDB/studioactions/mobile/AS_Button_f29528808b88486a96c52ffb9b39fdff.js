function AS_Button_f29528808b88486a96c52ffb9b39fdff(eventobject) {
    if (taskDetail.deleteButtonAndroid.text === "DELETE") {
        deleteTask();
    } else {
        taskList.show();
    }
}