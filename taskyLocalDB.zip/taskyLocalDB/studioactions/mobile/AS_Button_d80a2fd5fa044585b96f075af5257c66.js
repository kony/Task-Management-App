function AS_Button_d80a2fd5fa044585b96f075af5257c66(eventobject) {
    return AddnewTask.call(this);
}